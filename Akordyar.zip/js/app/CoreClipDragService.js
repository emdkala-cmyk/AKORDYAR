/*
 * CoreClipDragService
 *
 * Owns timeline clip/section move and resize mutations. Pointer event
 * orchestration remains in CoreClipInteractionService; this module only
 * changes DAW drag state and commits the completed operation.
 */
(function attachCoreClipDragService(globalScope) {
  'use strict';

  function create({
    documentRef = globalScope.document,
    getDAW = () => globalScope.RuntimeStateAdapter?.getDAW?.() || null,
    getClip = () => null,
    xToTime = value => value,
    snapTime = value => value,
    roundMs = value => value,
    clamp = (value, min, max) => Math.max(min, Math.min(max, value)),
    ensureTimelineFits = () => {},
    refreshClipWaveImage = () => {},
    saveState = () => {},
    scheduleAllFromPlayhead = () => {},
    renderAll = () => {}
  } = {}) {
    let dragOverLaneTrackId = null;

    function updateDragOverLane(event, daw) {
      const pointerTarget =
        documentRef?.elementFromPoint?.(event.clientX, event.clientY) ||
        event.target;
      const targetLane = pointerTarget?.closest?.('.track-lane');
      if (!targetLane) {
        dragOverLaneTrackId = null;
        return;
      }

      const laneTrackId = targetLane.dataset?.trackId;
      const targetTrack = (daw.tracks || []).find(
        track => track.id === laneTrackId
      );
      dragOverLaneTrackId =
        targetTrack?.type === 'audio' ? laneTrackId : null;
    }

    function updateMoveDrag(delta, daw) {
      daw.drag.items.forEach(item => {
        const target = item._isSection
          ? (daw.sections || []).find(section => section.id === item.id)
          : getClip(item.id);
        if (!target) return;
        target.start = Math.max(
          0,
          roundMs(snapTime(item.origStart + delta))
        );
        ensureTimelineFits(
          target.start + (target.duration || item.origDur) + 5
        );
      });
    }

    function updateResizeDrag(delta, daw) {
      const item = daw.drag.items.find(
        entry => entry.id === daw.drag.primaryId
      );
      const clip = getClip(daw.drag.primaryId);
      if (!item || !clip) return;

      if (daw.drag.edge === 'right') {
        const maxDur = clip.type === 'chord'
          ? 1000
          : clip.sourceDuration - clip.offset;
        clip.duration = clamp(
          roundMs(snapTime(item.origDur + delta)),
          0.03,
          maxDur
        );
        if (clip.type === 'audio') refreshClipWaveImage(clip);
        return;
      }

      let newStart = item.origStart + delta;
      let newOffset = item.origOffset + delta;
      let newDuration = item.origDur - delta;
      if (clip.type === 'chord') {
        if (newStart < 0) {
          newDuration += newStart;
          newStart = 0;
        }
        if (newDuration > 0.03) {
          clip.start = roundMs(snapTime(newStart));
          clip.duration = roundMs(
            item.origStart + item.origDur - snapTime(newStart)
          );
        }
        return;
      }

      if (newOffset < 0) {
        newStart -= newOffset;
        newDuration += newOffset;
        newOffset = 0;
      }
      if (newStart < 0) {
        const shift = -newStart;
        newStart = 0;
        newOffset += shift;
        newDuration -= shift;
      }
      if (
        newDuration >= 0.03 &&
        newOffset + newDuration <= clip.sourceDuration + 1e-6
      ) {
        clip.start = roundMs(newStart);
        clip.offset = roundMs(newOffset);
        clip.duration = roundMs(newDuration);
        refreshClipWaveImage(clip);
      }
    }

    function update(event) {
      const daw = getDAW();
      if (!daw?.drag) return false;

      const delta = xToTime(event.clientX - daw.drag.startX);
      if (daw.drag.type === 'move') {
        updateDragOverLane(event, daw);
        updateMoveDrag(delta, daw);
      } else if (daw.drag.type === 'resize') {
        updateResizeDrag(delta, daw);
      }
      return true;
    }

    function finish() {
      const daw = getDAW();
      if (!daw?.drag) return false;

      if (daw.drag.type === 'move' && dragOverLaneTrackId) {
        daw.drag.items.forEach(item => {
          const clip = getClip(item.id);
          if (clip && !item._isSection) {
            clip.trackId = dragOverLaneTrackId;
          }
        });
      }
      dragOverLaneTrackId = null;
      daw.drag = null;
      saveState();
      if (daw.isPlaying) scheduleAllFromPlayhead();
      renderAll();
      return true;
    }

    return Object.freeze({ update, finish });
  }

  const service = Object.freeze({ create });
  globalScope.CoreClipDragService = service;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = service;
  }
})(typeof window !== 'undefined' ? window : globalThis);
